import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { DataserviceService } from '../dataservice.service';
import { Users } from '../Users';

@Component({
  selector: 'app-createuser',
  templateUrl: './createuser.component.html',
  styleUrls: ['./createuser.component.css']
})
export class CreateuserComponent implements OnInit {
  users!: Observable<Users[]>;
  user:Users=new Users();

  constructor(private service:DataserviceService, private router: Router) { }

  ngOnInit(): void {
  }

  saveuser(){
    this.user.role='Customer';
     this.service.createUser(this.user)
      .subscribe(
        data => { console.log(data); alert('user is added');
        this.router.navigate(['/login'])},
        error => { console.log(error);  alert(error);}
      );
    
  }

}
