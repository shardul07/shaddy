export class Users{
    userId:number=0;
    userName:string='';
    email:string='';
    password:string='';
    role:string='';
    mobile:string='';
    address:string='';
    
}