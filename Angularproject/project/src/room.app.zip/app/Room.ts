export class Room {
    hotelId: number=0;
    available: string='';
    roomId:number=0;
    ratePerDay: number=0;
    roomNo: string='';
    roomType: string='';
      
}