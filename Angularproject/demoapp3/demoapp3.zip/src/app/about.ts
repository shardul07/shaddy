export class About{
    id: number=0;
    title: string='';
    matter: string='';
}