export class Booking{
    id: number=0;
    title: string='';
    year: number=0;
    author: string='';

}
