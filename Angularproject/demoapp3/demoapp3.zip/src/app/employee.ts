export class Employee {
    id: number=0;
    name: string='';
    salary: number=0;
    department: string='';

}